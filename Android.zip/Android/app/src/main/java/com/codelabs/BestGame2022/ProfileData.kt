package com.codelabs.BestGame2022

import com.codelabs.BestGame2022.R

object ProfileData {
    private val profileImage = intArrayOf(
        R.drawable.kevin
    )
    private val profileName = arrayOf(
        "Muhamad Kevin Fairuz"
    )
    private  val profileAbout = arrayOf(
        "Saya Muhamad Kevin Fairuz dari Falkutas Ilmu dan Teknik Komputer Jurusan Teknik Informatika angkatan 2022 dengan NIM : 10122345, Lahir di Bandung pada 16 Juni 2003. Saya memiliki cita-cita sebagai programmer karena hobi saya pada komputer menjadikan saya sangat semangat untuk menggapainya"
    )

}